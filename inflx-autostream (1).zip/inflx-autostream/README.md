# 🎬 AutoStream AI Agent
### Social-to-Lead Conversational AI — Built for ServiceHive's Inflx Platform

> An agentic AI system that converts social conversations into qualified leads using LangGraph, RAG, and Claude 3 Haiku.

---

## 📁 Project Structure

```
inflx-autostream/
├── agent/
│   ├── autostream_agent.py     # Main LangGraph agent + state management
│   ├── intent_detector.py      # Intent classification (greeting / inquiry / high-intent)
│   └── rag_pipeline.py         # RAG: loads & formats the knowledge base
├── tools/
│   └── lead_capture.py         # mock_lead_capture() tool function
├── knowledge_base/
│   └── autostream_kb.json      # AutoStream pricing, features, policies, FAQs
├── main.py                     # CLI entry point
├── whatsapp_webhook.py         # WhatsApp Business API webhook (bonus)
├── requirements.txt
├── .env.example
└── README.md
```

---

## ⚡ Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/inflx-autostream.git
cd inflx-autostream
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Set up environment variables
```bash
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

Get your Anthropic API key at: https://console.anthropic.com

### 5. Run the agent
```bash
python main.py
```

---

## 💬 Example Conversation

```
You: Hi! Tell me about your pricing.

Aria: Hey there! 👋 Welcome to AutoStream! We have two plans:

• Basic Plan — $29/month: 10 videos/month, 720p quality, email support
• Pro Plan — $79/month: Unlimited videos, 4K quality, AI captions, 24/7 support

Which one sounds like a better fit for your content?

---

You: The Pro plan sounds great! I want to try it for my YouTube channel.

Aria: Awesome, let's get you started! 🚀 First, what's your name?

---

You: Alex Johnson

Aria: Great to meet you, Alex Johnson! 🎉 What's your email address so we can set up your account?

---

You: alex@example.com

Aria: Got it — alex@example.com ✅
One last thing: which creator platform are you primarily on?

---

You: YouTube

[Terminal prints:]
═══════════════════════════════════════════════════
✅  LEAD CAPTURED SUCCESSFULLY
═══════════════════════════════════════════════════
  Lead ID  : LEAD-1718291234
  Name     : Alex Johnson
  Email    : alex@example.com
  Platform : Youtube
═══════════════════════════════════════════════════

Aria: 🎊 You're all set, Alex Johnson! We've registered your AutoStream Pro trial
and you'll receive a welcome email at alex@example.com shortly...
```

---

## 🏗 Architecture Explanation

### Why LangGraph?

LangGraph was chosen over AutoGen because it offers **explicit, deterministic control flow** — critical for a lead-capture agent where premature tool execution (asking for lead info before the user is ready) would be a bad user experience. LangGraph's `StateGraph` model lets us define clear nodes and conditional routing edges, making the conversation flow easy to audit and extend.

AutoGen's multi-agent approach is powerful for open-ended tasks, but our workflow is **pipeline-shaped**: Detect Intent → Answer via RAG → Collect Lead → Fire Tool. A directed graph maps to this naturally.

### State Management

All conversation state lives in a single `AgentState` TypedDict that LangGraph passes between nodes on every graph tick:

```python
class AgentState(TypedDict):
    messages: list           # Full chat history (Human + AI)
    intent: str              # Classified intent of latest message
    collecting_lead: bool    # Are we mid-collection?
    lead_name: str | None    # Collected name
    lead_email: str | None   # Collected email
    lead_platform: str | None # Collected platform
    lead_captured: bool      # Has mock_lead_capture() fired?
    turn_count: int          # Conversation depth
```

Because the state is passed **in full** to every node, the agent retains memory across 5–6+ turns with zero external dependencies — no Redis, no database. The `messages` list also serves as the conversation history injected into every LLM call, giving Claude full context of what was said before.

### RAG Pipeline

The knowledge base (`autostream_kb.json`) is loaded once at startup and converted into a structured markdown-style context string. This context is injected into every system prompt via `build_system_prompt()`. This approach — sometimes called "context stuffing" — works well for small-to-medium knowledge bases and avoids the latency of vector similarity search. For a larger knowledge base, this could be upgraded to embeddings + FAISS/Chroma retrieval.

### Intent Detection

A two-layer classifier: keyword heuristics run first (fast, zero latency), and the LLM handles nuanced responses naturally through the system prompt. High-intent signals take priority over greeting signals to avoid missing a hot lead.

### Tool Execution Safety

`mock_lead_capture()` is only called after all three fields (name, email, platform) are non-null and `lead_captured` is False. The `lead_collection_node` acts as a state machine — it checks what's missing and asks for exactly one field at a time, preventing both premature firing and repeated requests.

---

## 📱 WhatsApp Deployment via Webhooks

### How it works

```
User sends WhatsApp message
        │
        ▼
Meta WhatsApp Cloud API
        │  (HTTP POST)
        ▼
Your Flask Webhook Server  (/webhook endpoint)
        │
        ▼
Extract phone number + message text
        │
        ▼
Lookup or create AutoStreamAgent session (keyed by phone number)
        │
        ▼
agent.chat(user_message)  →  LangGraph processes turn
        │
        ▼
Send reply via WhatsApp Cloud API  (HTTP POST back to Meta)
        │
        ▼
User receives response on WhatsApp
```

### Step-by-Step Integration

**1. Set up Meta Developer App**
- Go to https://developers.facebook.com → Create App → Business
- Add the WhatsApp product
- Note your `Phone Number ID` and generate a `Permanent Token`

**2. Configure Webhook**
- In the WhatsApp dashboard, go to Configuration → Webhooks
- Set Callback URL: `https://yourdomain.com/webhook`
- Set Verify Token: match `VERIFY_TOKEN` in your `.env`
- Subscribe to the `messages` webhook field

**3. Run locally with ngrok (for development)**
```bash
pip install flask
python whatsapp_webhook.py    # Starts Flask on port 5000

# In another terminal:
ngrok http 5000               # Get a public HTTPS URL
# Paste the ngrok URL as your Webhook URL in Meta dashboard
```

**4. Environment variables needed**
```env
WHATSAPP_TOKEN=your_permanent_token
PHONE_NUMBER_ID=your_phone_number_id
VERIFY_TOKEN=autostream_verify_123
ANTHROPIC_API_KEY=your_anthropic_key
```

**5. Session Management at Scale**

In the current implementation, sessions are stored in a Python dict (in-memory). For production:
- Use **Redis** with a TTL (e.g., 24 hours) to store serialized `AgentState` per phone number
- Key: `session:{phone_number}` → Value: JSON-serialized state dict
- This survives server restarts and scales across multiple instances

**6. Deploy to Production**
```bash
# Dockerfile example
FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
CMD ["gunicorn", "whatsapp_webhook:app", "--bind", "0.0.0.0:8080"]
```
Deploy to: Railway, Render, AWS ECS, or Google Cloud Run.

---

## 🔧 Configuration

| Variable | Description | Required |
|---|---|---|
| `ANTHROPIC_API_KEY` | Claude 3 Haiku API key | ✅ Yes |
| `WHATSAPP_TOKEN` | Meta WhatsApp permanent token | WhatsApp only |
| `PHONE_NUMBER_ID` | WhatsApp Business phone number ID | WhatsApp only |
| `VERIFY_TOKEN` | Webhook verification secret | WhatsApp only |

---

## 🧪 Running Tests (Manual)

Test the intent detector directly:
```python
from agent.intent_detector import classify_intent

print(classify_intent("Hi there!"))                          # greeting
print(classify_intent("What's the price of the Pro plan?")) # product_inquiry
print(classify_intent("I want to sign up for Pro"))         # high_intent
```

Test the lead capture tool:
```python
from tools.lead_capture import mock_lead_capture
mock_lead_capture("Alex Johnson", "alex@example.com", "YouTube")
```

---

## 📦 Dependencies

| Package | Purpose |
|---|---|
| `langchain` | LLM abstraction layer |
| `langchain-anthropic` | Claude 3 Haiku integration |
| `langgraph` | Stateful graph-based agent orchestration |
| `python-dotenv` | Environment variable management |
| `flask` | Webhook server (WhatsApp integration) |
| `requests` | HTTP client for WhatsApp API calls |

---

## 🚀 Built For

- **Company**: ServiceHive
- **Product**: Inflx — Social-to-Lead AI Platform  
- **Assignment**: Machine Learning Intern Project
- **Agent persona**: Aria, AutoStream's AI sales assistant
