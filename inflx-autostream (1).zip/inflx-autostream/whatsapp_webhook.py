"""
whatsapp_webhook.py
Example WhatsApp Business API webhook integration for the AutoStream agent.

This shows how you would deploy the agent to WhatsApp using:
  - Meta WhatsApp Business Cloud API
  - Flask as the webhook HTTP server
  - Per-user agent instances (session management)

Setup:
1. Create a Meta Developer App → WhatsApp product
2. Set Webhook URL to: https://yourdomain.com/webhook
3. Subscribe to: messages
4. Set WHATSAPP_TOKEN and VERIFY_TOKEN in your .env

Run locally with ngrok for testing:
  ngrok http 5000
  Then set the ngrok URL as your webhook in Meta Developer Dashboard.
"""

import os
import json
import requests
from flask import Flask, request, jsonify
from dotenv import load_dotenv

from agent.autostream_agent import AutoStreamAgent

load_dotenv()

app = Flask(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
WHATSAPP_TOKEN = os.getenv("WHATSAPP_TOKEN")   # From Meta Developer Dashboard
VERIFY_TOKEN   = os.getenv("VERIFY_TOKEN", "autostream_verify_123")
PHONE_NUMBER_ID = os.getenv("PHONE_NUMBER_ID") # Your WhatsApp Business number ID

# ── In-memory session store (use Redis in production) ─────────────────────────
# Maps WhatsApp phone number → AutoStreamAgent instance
user_sessions: dict[str, AutoStreamAgent] = {}


def get_or_create_agent(phone_number: str) -> AutoStreamAgent:
    """Return existing agent session or create a new one for this user."""
    if phone_number not in user_sessions:
        user_sessions[phone_number] = AutoStreamAgent()
    return user_sessions[phone_number]


def send_whatsapp_message(to: str, body: str):
    """Send a text message back to the user via WhatsApp Cloud API."""
    url = f"https://graph.facebook.com/v18.0/{PHONE_NUMBER_ID}/messages"
    headers = {
        "Authorization": f"Bearer {WHATSAPP_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"body": body}
    }
    response = requests.post(url, headers=headers, json=payload)
    return response.json()


# ── Webhook Verification (GET) ────────────────────────────────────────────────
@app.route("/webhook", methods=["GET"])
def verify_webhook():
    """
    Meta sends a GET request to verify your webhook URL.
    Respond with the hub.challenge value if tokens match.
    """
    mode      = request.args.get("hub.mode")
    token     = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    if mode == "subscribe" and token == VERIFY_TOKEN:
        print("✅ Webhook verified by Meta")
        return challenge, 200
    else:
        return "Forbidden", 403


# ── Incoming Messages (POST) ──────────────────────────────────────────────────
@app.route("/webhook", methods=["POST"])
def receive_message():
    """
    Meta sends a POST request when a user messages your WhatsApp number.
    Extract the message, run it through the agent, reply.
    """
    data = request.get_json()

    try:
        entry    = data["entry"][0]
        changes  = entry["changes"][0]
        value    = changes["value"]
        messages = value.get("messages", [])

        if not messages:
            return jsonify({"status": "no_message"}), 200

        msg          = messages[0]
        from_number  = msg["from"]          # Sender's WhatsApp number
        message_type = msg["type"]

        if message_type != "text":
            # Ignore non-text messages (images, voice notes, etc.)
            send_whatsapp_message(from_number, "I can only handle text messages right now. Please type your question!")
            return jsonify({"status": "non_text_ignored"}), 200

        user_text = msg["text"]["body"]
        print(f"📩 Message from {from_number}: {user_text}")

        # Route through the AutoStream agent
        agent    = get_or_create_agent(from_number)
        response = agent.chat(user_text)

        # Send reply back to the user
        send_whatsapp_message(from_number, response)
        print(f"📤 Sent to {from_number}: {response[:80]}...")

    except (KeyError, IndexError) as e:
        print(f"⚠️  Webhook parse error: {e}")

    return jsonify({"status": "ok"}), 200


# ── Health Check ──────────────────────────────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "running", "agent": "AutoStream AI", "sessions": len(user_sessions)})


if __name__ == "__main__":
    print("🚀 AutoStream WhatsApp Webhook Server starting on port 5000...")
    print("   Expose with: ngrok http 5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
